﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AA
{
    class Program
    {
        //A*
        static void Main()
        {
            Node node = new();
            node.InitFirstNode();

            HashSet<Node> visited = new HashSet<Node>();


            PriorityQueue<Node, int> queue = new PriorityQueue<Node, int>();
            Stack<Node> resultStack = new Stack<Node>();

            visited.Add(node);

            queue.Enqueue(node, node.Mark);


            while (queue.Count > 0)
            {
                node = queue.Dequeue();
                if (node.IsFinal())
                {
                    while (node.Parent != null)
                    {
                        resultStack.Push(node);
                        node = node.Parent;
                    }
                    while (resultStack.Count > 0)
                    {
                        Node printResult = resultStack.Pop();
                        Console.WriteLine(printResult);
                    }
                    break;

                }

                else
                {
                    var ext = new List<Node>();

                    if (node.Parent == null)
                    {
                        ext = node.Extensions();
                    }

                    if (!visited.Contains(node))
                    {
                        ext = node.Extensions();
                        visited.Add(node);
                    }

                    while (ext.Count > 0)
                    {

                        queue.Enqueue(ext[ext.Count - 1], ext[ext.Count - 1].Mark);
                        ext.RemoveAt(ext.Count - 1);

                    }

                }
            }

            
        }



    }
}
