﻿namespace AA
{
    
    internal class Node
    {
        
       
        internal int[,] Matrix { get; private set; } = new int[3, 3];

        private int emptyIndexRow { get; set; }
        private int emptyIndexCol { get; set; }

        internal int Steps { get; private set; } = 0; 
        private int manheten; 

        internal int Mark
        {
            get { return Steps + manheten; }
        }
        
        internal Node? Parent { get; private set; } = null;

        internal void InitFirstNode()
        {
            InitMatrix();
            SetEmptyIdx();
            SetManheten();

        }

        internal List<Node> Extensions()
        {
            var list = new List<Node>();
            var zi = this.emptyIndexRow;
            var zj = this.emptyIndexCol;

            int [][] index = new int [][]{ 
                new int[]{zi - 1, zj },
                new int[]{zi + 1, zj },
                new int[]{zi, zj - 1 },
                new int[]{zi, zj + 1 } };

            foreach (int[] ij in index)
            {

                if (Range(ij[0], ij[1]))
                {
                    var valIdxI = ij[0];
                    var valIdxJ = ij[1];

                    var node = new Node();
                    node.Matrix = CopyArray(Matrix); ;
                    node.SetEmptyIdx();
                    node.Steps = Steps + 1;
                    node.Swap(emptyIndexRow, emptyIndexCol, valIdxI, valIdxJ);
                    node.emptyIndexRow = valIdxI;
                    node.emptyIndexCol = valIdxJ;
                    this.SetEmptyIdx();
                    node.SetManheten();
                    node.Parent = this;
                    list.Add(node);
                }
            }

            return list;

        }

        internal bool IsFinal()
        {
            if (this.manheten == 0)
                return true;
            else
                return false;
        }
        public override string? ToString()
        {

            var s = "";

            for (int i = 0; i < Matrix.GetLength(0); i++)
            {
                for (int j = 0; j < Matrix.GetLength(1); j++)
                {
                    s += " " + Matrix[i, j];
                }

                s += "\n";
            }
            s += $"emptyIdx: ({emptyIndexRow},{emptyIndexCol}), Steps: {Steps}, manheten: {manheten}, mark: {Mark}\n";
            return s;
        }

        private void InitMatrix()
        {
            for (int i = 0; i < Matrix.GetLength(0); i++)
            {
                for (int j = 0; j < Matrix.GetLength(1); j++)
                {
                    Matrix[i, j] = (Matrix.GetLength(0) * i) + j + 1;
                    
                }

            }

            Matrix[2, 2] = 0;
            SetEmptyIdx();

            var r = new Random(Environment.TickCount);

            for (int i = 0; i < 1000; i++)
            {
                var exts = Extensions();
                var chosen = exts[r.Next(exts.Count)];
                Matrix = chosen.Matrix;
                SetEmptyIdx();
            }
        }

        private void SetEmptyIdx()
        {
            for (int i = 0; i < Matrix.GetLength(0); i++)
            {
                for (int j = 0; j < Matrix.GetLength(1); j++)
                {
                    if (Matrix[i,j] == 0)
                    {
                        emptyIndexRow = i;
                        emptyIndexCol = j;
                        break;
                    }
                }
            }
        }
        
        private void SetManheten()
        {
            
            for(int i = 0; i < Matrix.GetLength(0); i++)
            {
                for (int j = 0; j < Matrix.GetLength(1); j++)
                {

                    if (Matrix[i,j] != 0)
                    {
                         

                        var ii = (Matrix[i, j] - 1) / Matrix.GetLength(0);
                        var ij = (Matrix[i, j] - 1) % Matrix.GetLength(1);
                        manheten += Math.Abs(i - ii) + Math.Abs(j - ij);

                    }

                }
            }
        }
        private bool Range(int i, int j)
        {
            if ((i >= 0 && i <= 2) && (j >= 0 && j <= 2))
                return true;
            else
                return false;
        }
        private void Swap(int emptyIndexRow, int emptyIndexCol, int valIdxI, int valIdxJ)
        {
            var tempVal = Matrix[emptyIndexRow, emptyIndexCol];
            this.Matrix[emptyIndexRow, emptyIndexCol] = this.Matrix[valIdxI, valIdxJ];
            this.Matrix[valIdxI, valIdxJ] = tempVal;
        }



        private int[,] CopyArray(int[,] arr)
        {
            int[,] res = new int[arr.GetLength(0), arr.GetLength(1)];
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                    res[i, j] = arr[i, j];
                }
            }

            return res;
        }


    }
}